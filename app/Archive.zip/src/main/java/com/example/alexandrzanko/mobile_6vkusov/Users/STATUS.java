package com.example.alexandrzanko.mobile_6vkusov.Users;

/**
 * Created by alexandrzanko on 3/1/17.
 */

public enum STATUS {
    GENERAL,REGISTER
}
