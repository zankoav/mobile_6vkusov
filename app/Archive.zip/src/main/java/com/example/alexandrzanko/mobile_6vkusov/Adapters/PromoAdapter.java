package com.example.alexandrzanko.mobile_6vkusov.Adapters;

/**
 * Created by alexandrzanko on 5/2/17.
 */

public class PromoAdapter {
}
