package com.example.alexandrzanko.mobile_6vkusov.Models;

/**
 * Created by alexandrzanko on 5/2/17.
 */

public class Promo {
}
